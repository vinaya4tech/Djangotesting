
from django.test import SimpleTestCase
from django.urls import reverse,resolve
from ...budget.views import project_detail,project_list,ProjectCreateView


class TestUrls(SimpleTestCase):
    def test_list_url_is_resolved(self):
        url = reverse('list')
        print(resolve(url))